#ifndef ADP_I2_HP_LS_REPL_H_
#define ADP_I2_HP_LS_RRIP_REPL_H_

#include "repl_policies.h"

class ADP_I2_HP_LSReplPolicy : public ReplPolicy {
    protected:
        uint64_t timestamp; // incremented on each access
        uint64_t* array;
        uint32_t numLines;
        uint32_t rpvMax;
        uint32_t miss;

    public:
        explicit ADP_I2_HP_LSReplPolicy(uint32_t _numLines, uint32_t _rpvMax) : timestamp(1), numLines(_numLines),rpvMax(_rpvMax), miss(0) {
            array = gm_calloc<uint64_t>(numLines);
               for ( uint32_t i=0; i<numLines; i++)
		{
		   array[numLines]= 0;
		}
        }

        ~ADP_I2_HP_LSReplPolicy() {
            gm_free(array);
        }

        void update(uint32_t id, const MemReq* req) {
            if(!miss)
		{
		//printf("\nThis is hit case, updating value of %d to 3",id );
		array[id] = 3;
        	}
            miss=0;
	}

        void replaced(uint32_t id) {
	    // printf("\nThis is miss case, updating value of %d to 1", id);
             array[id] = 2;
             miss = 1;
        }
	
	template <typename C> inline uint32_t calculate_ave(C cands){
                uint32_t sum=0;
                uint32_t count=0;
		
                uint32_t ave=0;
//	printf("\ncalculating average of ");
                for (auto ci = cands.begin(); ci != cands.end(); ci.inc()) {
//			printf("%d  ",int(array[*ci]));
                        sum += array[*ci];
                        count +=1;
                }
                ave = sum/count;
//		printf("%d  ", ave);
		count =0; 
            return ave;
        }

        template <typename C> inline void update_priority(C cands, uint32_t average) {
        for (auto ci = cands.begin(); ci != cands.end(); ci.inc()){
                        if(average >array[*ci]) array[*ci] =0;
                        else array[*ci] = array[*ci] - average ;
                        }
        }
	template <typename C> inline uint64_t search_candidate(C cands){
            for (auto ci = cands.begin(); ci != cands.end(); ci.inc()) {
                if(array[*ci] == 0) {
                        return *ci; }   //No CC in consideration
                }
            return -1;
        }

        template <typename C> inline uint32_t rank(const MemReq* req, C cands) {
            uint64_t bestCand = -1;
	    uint32_t avg = 0;
	    avg = calculate_ave(cands);  
	    bestCand = -1;
            while(bestCand == -1){
                bestCand = search_candidate(cands);
//	    	printf("\nInitial bestCand value is %d", int(bestCand)); 
                if(bestCand == -1)  //No value of 3 found, increment all set values
                	{
			auto ci = cands.begin();	
//	    		printf("In this miss case *ci start is %d",*ci);	
                        for (ci = cands.begin(); ci != cands.end(); ci.inc()){
                 	if(avg >array[*ci]) array[*ci] =0;
                        else array[*ci] = array[*ci] - avg ;       
			 }
                	}
            }
//	printf("\nIn this miss case bestCand is %d",bestCand);	
        return bestCand;
	}
        
	DECL_RANK_BINDINGS;
#if 0
	 a:  for (auto ci = cands.begin(); ci != cands.end(); ci.inc()) {
                uint32_t s = array[*ci];
		if(s == 0 && flag !=1 )
		{
	        bestCand = *ci;
		flag = 1;
		}
            }
		if(flag == 0 && flag2 == 0)
		{ sum = 0; ctr = 0;
             for (auto ci = cands.begin(); ci != cands.end(); ci.inc())
		{
		 sum = sum + array[*ci];
		 ctr = ctr + 1;
                }
		avg = sum/ctr;
		if(avg == 0)
		{
		avg=3;
	 	cout<<"sum"<<sum<<"\n";	
		} 
	    for (auto ci = cands.begin(); ci != cands.end(); ci.inc())
		{
                 array[*ci] = array[*ci] - avg;
		if( array[*ci] <= 0)
		{
		  array[*ci] = 0;
		}
                 uint32_t s = array[*ci];
                	if(s == 0) 
			{
                		flag2 = 1;
			}
                }

		
		if(flag2 == 0)
		{
			sum = 0;
			ctr = 0;
			cout<<"Problem"<<"\n";
	//		goto b;
		}
		
		else if (flag2 == 1)
		{
		        goto a;
		}
		}

		if(flag == 1)
		{
            	return bestCand;
		}
		else
		{
		return 0;
		}
        }
#endif
    private:
        inline uint64_t score(uint32_t id) { //higher is least evictable
            //array[id] < timestamp always, so this prioritizes by:
            // (1) valid (if not valid, it's 0)
            // (2) sharers, and
            // (3) timestamp
		if(cc->isValid(id))
		{
			return(3);
		}
		else
		{
			return(array[id]);
		}
        }
};


#endif // RRIP_REPL_H_
